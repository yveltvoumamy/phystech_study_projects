#ifndef RATIONAL_H
#define RATIONAL_H

#include <stdexcept>
#include <iostream>
#include <numeric>

class RationalDivisionByZero : public std::runtime_error {
 public:
  RationalDivisionByZero() : std::runtime_error("RationalDivisionByZero") {
  }
};

class Rational {
  int32_t num_, den_;
  inline void Reduction() {
    int32_t tmp = std::gcd(num_, den_);
    num_ /= tmp;
    den_ /= tmp;
    if (den_ < 0) {
      num_ *= -1;
      den_ *= -1;
    }
  }

 public:
  Rational();
  Rational(int32_t x);  // NOLINT
  Rational(int32_t x, int32_t y);
  int32_t GetNumerator() const;
  int32_t GetDenominator() const;
  void SetNumerator(int32_t x);
  void SetDenominator(int32_t x);
  friend Rational operator+(const Rational& x, const Rational& y);
  friend Rational operator-(const Rational& x, const Rational& y);
  friend Rational operator/(const Rational& x, const Rational& y);
  friend Rational operator*(const Rational& x, const Rational& y);
  Rational& operator+=(const Rational& x);
  Rational& operator-=(const Rational& x);
  Rational& operator/=(const Rational& x);
  Rational& operator*=(const Rational& x);
  friend Rational operator+(const Rational& x);
  friend Rational operator-(const Rational& x);
  Rational& operator++();
  Rational operator++(int32_t);
  Rational& operator--();
  Rational operator--(int32_t);
  friend bool operator<(const Rational& x, const Rational& y);
  friend bool operator>(const Rational& x, const Rational& y);
  friend bool operator==(const Rational& x, const Rational& y);
  friend bool operator!=(const Rational& x, const Rational& y);
  friend bool operator<=(const Rational& x, const Rational& y);
  friend bool operator>=(const Rational& x, const Rational& y);
  friend std::istream& operator>>(std::istream& is, Rational& x);
  friend std::ostream& operator<<(std::ostream& os, const Rational& x);
};
#endif