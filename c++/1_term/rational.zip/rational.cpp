#include "rational.h"

Rational::Rational() {
  num_ = 0;
  den_ = 1;
}

Rational::Rational(int32_t x) {
  num_ = x;
  den_ = 1;
}

Rational::Rational(int32_t x, int32_t y) {
  if (y == 0) {
    throw RationalDivisionByZero{};
  } else {
    num_ = x;
    den_ = y;
    Rational::Reduction();
  }
}

int32_t Rational::GetNumerator() const {
  return num_;
}

int32_t Rational::GetDenominator() const {
  return den_;
}

void Rational::SetNumerator(int32_t x) {
  num_ = x;
  Reduction();
}

void Rational::SetDenominator(int32_t x) {
  if (x == 0) {
    throw RationalDivisionByZero{};
  } else if (x > 0) {
    den_ = x;
  } else {
    num_ *= -1;
    den_ = -x;
  }
  Reduction();
}

Rational operator+(const Rational& x, const Rational& y) {
  Rational s = x;
  s += y;
  return s;
}

Rational operator-(const Rational& x, const Rational& y) {
  Rational s = x;
  s -= y;
  return s;
}

Rational operator/(const Rational& x, const Rational& y) {
  if (y.num_ == 0) {
    throw RationalDivisionByZero{};
  } else {
    Rational s = x;
    s /= y;
    return s;
  }
}

Rational operator*(const Rational& x, const Rational& y) {
  Rational s = x;
  s *= y;
  return s;
}

Rational& Rational::operator+=(const Rational& x) {
  num_ = den_ * x.num_ + num_ * x.den_;
  den_ *= x.den_;
  Rational::Reduction();
  return *this;
}

Rational& Rational::operator-=(const Rational& x) {
  num_ = x.den_ * num_ - x.num_ * den_;
  den_ *= x.den_;
  Rational::Reduction();
  return *this;
}

Rational& Rational::operator/=(const Rational& x) {
  if (x.num_ == 0) {
    throw RationalDivisionByZero{};
  } else {
    num_ *= x.den_;
    den_ *= x.num_;
    Rational::Reduction();
    return *this;
  }
}

Rational& Rational::operator*=(const Rational& x) {
  num_ *= x.num_;
  den_ *= x.den_;
  Rational::Reduction();
  return *this;
}

Rational operator+(const Rational& x) {
  return {x.num_, x.den_};
}

Rational operator-(const Rational& x) {
  return {-x.num_, x.den_};
}

Rational& Rational::operator++() {
  num_ += den_;
  Reduction();
  return *this;
}

Rational Rational::operator++(int32_t) {
  Rational x = *this;
  *this += 1;
  return x;
}

Rational& Rational::operator--() {
  num_ -= den_;
  Reduction();
  return *this;
}

Rational Rational::operator--(int32_t) {
  Rational x = *this;
  *this -= 1;
  return x;
}

bool operator<(const Rational& x, const Rational& y) {
  return y.den_ * x.num_ < y.num_ * x.den_;
}
bool operator>(const Rational& x, const Rational& y) {
  return y < x;
}

bool operator==(const Rational& x, const Rational& y) {
  return !(x > y || y > x);
}

bool operator!=(const Rational& x, const Rational& y) {
  return x > y || y > x;
}

bool operator<=(const Rational& x, const Rational& y) {
  return x == y || x < y;
}

bool operator>=(const Rational& x, const Rational& y) {
  return x == y || x > y;
}

std::istream& operator>>(std::istream& is, Rational& x) {
  is >> x.num_;
  if (is.peek() == '/') {
    char t;
    is >> t >> x.den_;
    if (x.den_ == 0) {
      throw RationalDivisionByZero{};
    }
    x.Reduction();
    return is;
  }
  x.den_ = 1;
  x.Reduction();
  return is;
}

std::ostream& operator<<(std::ostream& os, const Rational& x) {
  if (x.den_ == 1) {
    os << x.num_;
    return os;
  }
  os << x.num_ << '/' << x.den_;
  return os;
}