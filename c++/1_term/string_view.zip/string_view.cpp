#include "string_view.h"
#include <cstring>

StringView::StringView() : str_(nullptr) {
}

StringView::StringView(const char* str) : str_(str), size_(strlen(str_)) {
}

StringView::StringView(const char* str, size_t size) : str_(str), size_(size) {
}

const char& StringView::operator[](size_t idx) const {
  return str_[idx];
}

const char& StringView::At(size_t idx) const {
  if (idx < Size()) {
    return str_[idx];
  }
  throw StringViewOutOfRange{};
}

const char& StringView::Front() const {
  return str_[0];
}

const char& StringView::Back() const {
  return str_[Size() - 1];
}

size_t StringView::Size() const {
  return size_;
}

size_t StringView::Length() const {
  return Size();
}

bool StringView::Empty() const {
  return Size() == 0;
}

const char* StringView::Data() const {
  return str_;
}

void StringView::Swap(StringView& another_str) {
  std::swap(size_, another_str.size_);
  std::swap(str_, another_str.str_);
}

void StringView::RemovePrefix(size_t prefix_size) {
  size_ -= prefix_size;
  str_ += prefix_size;
}

void StringView::RemoveSuffix(size_t suffix_size) {
  size_ -= suffix_size;
}

StringView StringView::Substr(size_t pos, size_t counter = -1) {
  if (pos >= size_) {
    throw StringViewOutOfRange{};
  }
  auto string = str_ + pos;
  if (size_ - pos >= counter) {
    StringView new_string(string, counter);
    return new_string;
  }
  StringView new_string(string, size_ - pos);
  return new_string;
}