#ifndef STRING_VIEW_H
#define STRING_VIEW_H

#include <stdexcept>

class StringView {
 private:
  const char* str_;
  size_t size_;

 public:
  StringView();
  StringView(const char* str);  // NOLINT
  StringView(const char* str, size_t size);
  const char& operator[](size_t idx) const;
  const char& At(size_t idx) const;
  const char& Front() const;
  const char& Back() const;
  size_t Size() const;
  size_t Length() const;
  bool Empty() const;
  const char* Data() const;
  void Swap(StringView&);
  void RemovePrefix(size_t prefix_size);
  void RemoveSuffix(size_t suffix_size);
  StringView Substr(size_t pos, size_t counter);
};

class StringViewOutOfRange : public std::out_of_range {
 public:
  StringViewOutOfRange() : std::out_of_range("StringViewOutOfRange") {
  }
};
#endif